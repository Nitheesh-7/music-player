const myAudio = document.querySelector("audio")
const playButton = document.querySelector("#play")

// Audio is playing => PLAY to PAUSE
// Audio is not playing => PAUSE to PLAY

//To Track whether the audio is playing or not
let isAudioPlaying = false

function playTheAudio()
{
    myAudio.play()
    //immediately change play to pause
    // class="fa-solid fa-play"
    // access the class data
    playButton.classList.replace("fa-play", "fa-pause")
    isAudioPlaying = true
}

function pauseTheAudio()
{
    myAudio.pause()
    playButton.classList.replace("fa-pause", "fa-play")
    isAudioPlaying = false
}

// playButton(once) --> play the audio
// playButton(second time) --> pause the audio

playButton.addEventListener("click", function()
{
    if(isAudioPlaying)
    {
        pauseTheAudio()
    }
    else
    {
        playTheAudio()
    }
    
})

// When we click on forward button OR backward button, we have to consistently change the following things
// Image
// Song name
// Singer Name
// Audio File

const info = [
    {
       songName: "AAA",
       singerName: "Lil Nas X" 
    },
    {
        songName: "BBB",
        singerName: "ATB/Topic/A7S"
    },
    {
        songName: "CCC",
        singerName: "Ella Henderson & Tom Grennan"
    }
]

const forwardButton = document.querySelector("#forward")
const mySongName = document.querySelector("h3")
const mySingerName = document.querySelector("h4")
const backwardButton = document.querySelector("#backward")

// songData =  {
//     songName: "Montero (call me by your name)",
//     singerName: "Lil Nas X" 
//  }

function updateSong(songData){

    mySongName.textContent = songData.songName
    mySingerName.textContent = songData.singerName

}

let songPosition = 0

// songPosition = 2(last song) --> (0)first song

// 3


forwardButton.addEventListener("click", function()
{    
    // Update the Song data(image, singer name, song name, audio file)
    if(songPosition > info.length - 1)
    {
        songPosition = 0
    }

    updateSong(info[songPosition])
    console.log(songPosition)
    songPosition++

})


backwardButton.addEventListener("click", function()
{    
    // // Update the Song data(image, singer name, song name, audio file)
    // 2 1 0 2 1 0 2 1 0
    
    songPosition--

    if(songPosition < 0)
    {
        songPosition = info.length - 1
    }

    updateSong(info[songPosition])
    

})




// const questionInfo = [
//     {
//         question: "What is 1 + 1?",
//         A: "",
//         ,
//         ,
//         Answer: "A"

//     },
//     {

//     },
//     {

//     }
// ]